// config/database.js
module.exports = {
    'connection': {
        'host': 'localhost',
        'user': 'root',
        'password': null
    },
	'database': 'meetup',
    'users_table': 'users'
};