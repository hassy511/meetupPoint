var express  = require('express');
var bodyParser = require('body-parser');
var app      = express();

var NodeGeocoder = require('node-geocoder');
var mysql = require('mysql');
var dbconfig = require('../config/database');
var connection = mysql.createConnection(dbconfig.connection);
connection.query('USE ' + dbconfig.database);
var dateFormat = require('dateformat');

var lat,long;
var options = {
	provider: 'google',
   
	// Optional depending on the providers
	httpAdapter: 'https', // Default
	apiKey: 'AIzaSyB72zmpF8gvfybM_V_3jFZAy7IgtrxXK7E', // for Mapquest, OpenCage, Google Premier
	formatter: null         // 'gpx', 'string', ...
  };
   
  var geocoder = NodeGeocoder(options);
   
  // Or using Promise
  geocoder.geocode('29 champs elysée paris')
	.then(function(res) {
		lat = res[0].latitude;
		long = res[0].longitude;
	})
	.catch(function(err) {
	  console.log(err);
	});
// app/routes.js
module.exports = function(app, passport) {

	// =====================================
	// HOME PAGE (with login links) ========
	// =====================================
	app.get('/', function(req, res) {
		res.render('login.ejs', { message: req.flash('loginMessage') });
	});

	// =====================================
	// LOGIN ===============================
	// =====================================
	// show the login form
	app.get('/login', function(req, res) {
		res.render('login.ejs', { message: req.flash('loginMessage'),geocoder});
	});

	// process the login form
	app.post('/login', passport.authenticate('local-login', {
		    successRedirect : '/profile', // redirect to the secure profile section
            failureRedirect : '/login', // redirect back to the signup page if there is an error
            failureFlash : true // allow flash messages
		}),
        function(req, res) {
            console.log("In Post Function");

            if (req.body.remember) {
              req.session.cookie.maxAge = 1000 * 60 * 3;
            } else {
              req.session.cookie.expires = false;
            }
        res.redirect('/');
    });

	// =====================================
	// SIGNUP ==============================
	// =====================================
	// show the signup form
	app.get('/signup', function(req, res) {
		res.render('signup.ejs', { message: req.flash('signupMessage')});
	});

	// process the signup form
	app.post('/signup', passport.authenticate('local-signup', {
		successRedirect : '/profile', // redirect to the secure profile section
		failureRedirect : '/signup', // redirect back to the signup page if there is an error
		failureFlash : true // allow flash messages
	}));

	// =====================================
	// PROFILE SECTION =========================
	// =====================================
	// we will want this protected so you have to be logged in to visit
	// we will use route middleware to verify this (the isLoggedIn function)

	app.post('/discard', function(req, res){

		var obj = JSON.stringify(req.body);
		var objectValue = JSON.parse(obj);
		var currentUserId =  objectValue["currentUserId"];
		var masterId =  objectValue["masterId"];
		
		var sql = "DELETE FROM `meetingdetails` WHERE `userID` = '"+currentUserId+"' and `masterId` = '"+masterId+"'";

		connection.query(sql, function (err, result) {
			if (err) throw err;
		  });
		  res.send(sql);
	});

	app.post('/endpoint', function(req, res){

		var obj = JSON.stringify(req.body);
		var objectValue = JSON.parse(obj);
		var date = dateFormat(objectValue['date'], "yyyy-mm-dd");
		var location = objectValue['location'];
		var users = objectValue['users'];
		var currentUserId =  objectValue["currentUserId"];
		
		var sql = "INSERT INTO `meetingmasters`(`date`,`location`,`createdAt`, `updatedAt`, `scheduledById`) VALUES ('"+date+"','"+location+"',NOW(),NOW(),'"+currentUserId+"');";

		connection.query(sql, function (err, result) {
			if (err) throw err;
		  });

		users.forEach(element => {
			sql = "INSERT INTO `meetingdetails`(`masterId`, `userID`, `status`, `createdAt`, `updatedAt`) VALUES ((select max(id) from meetingmasters),'"+element+"',0,NOW(),NOW());";
			connection.query(sql, function (err, result) {
				if (err) throw err;
			  });
		});

		res.send(sql);
	});

	app.get('/profile', isLoggedIn, function(req, res) {
		var data = {};
		var meetings = {};
		var userData = [];
		var error = '';
		var userEmail = req.user.email;

		connection.query("SELECT `id`,`email`,`lat`, `long` FROM `users`", function(err, rows){
			if (err)
			{
				return err;
			}
			// all is well, return successful user
			else {
				if(res.length){
					for(var i = 0; i<res.length; i++ ){     
									data.push(res[i]);
						}
					 }
				
				data = rows;
				console.log("Abdul Haseeb");
				console.log(data);	
			}
			
			connection.query("SELECT a.`id`,a.`date`, a.`location`,c.`email` FROM `meetingmasters` as a inner join `meetingdetails` as b on a.id = b.masterId inner join `users` as c on a.`scheduledById` = c.id where b.userID = (select id from users where email = '"+userEmail+"')", function(err, rows){
				if (err)
				{
					return err;
				}
				// all is well, return successful user
				else {
					if(res.length){
						for(var i = 0; i<res.length; i++ ){     
							meetings.push(res[i]);
							}
						 }
					
					meetings = rows;
					console.log("Abdul Haseeb");
					console.log(meetings);	
					res.render('profile.ejs', {
						user : req.user, // get the user out of session and pass to template
						data,meetings
					});
					
				}
			});
			
			return data;
		});
	});

	// =====================================
	// LOGOUT ==============================
	// =====================================
	app.get('/logout', function(req, res) {
		req.logout();
		res.redirect('/');
	});
};

// route middleware to make sure
function isLoggedIn(req, res, next) {

	// if user is authenticated in the session, carry on
	if (req.isAuthenticated())
		return next();

	// if they aren't redirect them to the home page
	res.redirect('/');
}



