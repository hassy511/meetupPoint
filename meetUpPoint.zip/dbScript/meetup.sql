-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 06, 2019 at 04:19 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `meetup`
--

-- --------------------------------------------------------

--
-- Table structure for table `meetingdetails`
--

CREATE TABLE `meetingdetails` (
  `id` int(11) NOT NULL,
  `masterId` int(11) DEFAULT NULL,
  `userID` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meetingdetails`
--

INSERT INTO `meetingdetails` (`id`, `masterId`, `userID`, `status`, `createdAt`, `updatedAt`) VALUES
(12, 10, 3, 0, '2019-01-05 01:36:46', '2019-01-05 01:36:46'),
(13, 10, 7, 0, '2019-01-05 01:36:46', '2019-01-05 01:36:46'),
(15, 11, 3, 0, '2019-01-05 01:40:03', '2019-01-05 01:40:03'),
(16, 12, 1, 0, '2019-01-06 17:34:49', '2019-01-06 17:34:49'),
(17, 12, 3, 0, '2019-01-06 17:34:49', '2019-01-06 17:34:49'),
(18, 12, 6, 0, '2019-01-06 17:34:49', '2019-01-06 17:34:49'),
(19, 13, 1, 0, '2019-01-06 17:42:41', '2019-01-06 17:42:41'),
(20, 13, 2, 0, '2019-01-06 17:42:41', '2019-01-06 17:42:41'),
(21, 13, 8, 0, '2019-01-06 17:42:41', '2019-01-06 17:42:41'),
(23, 14, 6, 0, '2019-01-05 18:56:26', '2019-01-05 18:56:26'),
(24, 15, 6, 0, '2019-01-05 19:10:01', '2019-01-05 19:10:01'),
(25, 15, 5, 0, '2019-01-05 19:10:01', '2019-01-05 19:10:01'),
(26, 16, 6, 0, '2019-01-05 19:11:16', '2019-01-05 19:11:16'),
(27, 16, 3, 0, '2019-01-05 19:11:16', '2019-01-05 19:11:16'),
(28, 17, 1, 0, '2019-01-05 23:25:03', '2019-01-05 23:25:03'),
(29, 17, 3, 0, '2019-01-05 23:25:03', '2019-01-05 23:25:03'),
(30, 17, 7, 0, '2019-01-05 23:25:03', '2019-01-05 23:25:03'),
(32, 18, 3, 0, '2019-01-05 23:53:51', '2019-01-05 23:53:51'),
(33, 18, 7, 0, '2019-01-05 23:53:51', '2019-01-05 23:53:51'),
(34, 18, 8, 0, '2019-01-05 23:53:51', '2019-01-05 23:53:51'),
(36, 19, 3, 0, '2019-01-06 00:38:56', '2019-01-06 00:38:56'),
(37, 19, 6, 0, '2019-01-06 00:38:56', '2019-01-06 00:38:56'),
(38, 19, 8, 0, '2019-01-06 00:38:56', '2019-01-06 00:38:56'),
(40, 20, 8, 0, '2019-01-06 01:48:30', '2019-01-06 01:48:30'),
(41, 21, 1, 0, '2019-01-06 10:06:56', '2019-01-06 10:06:56'),
(42, 21, 3, 0, '2019-01-06 10:06:56', '2019-01-06 10:06:56'),
(43, 21, 5, 0, '2019-01-06 10:06:56', '2019-01-06 10:06:56'),
(44, 21, 6, 0, '2019-01-06 10:06:56', '2019-01-06 10:06:56');

-- --------------------------------------------------------

--
-- Table structure for table `meetingmasters`
--

CREATE TABLE `meetingmasters` (
  `id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `location` varchar(5000) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `scheduledById` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meetingmasters`
--

INSERT INTO `meetingmasters` (`id`, `date`, `location`, `createdAt`, `updatedAt`, `scheduledById`) VALUES
(10, '2019-01-21', 'Khan Briyani &amp; Juice Center, Karachi', '2019-01-05 01:36:46', '2019-01-05 01:36:46', 1),
(11, '2019-01-22', 'KFC, Block 4, Dolmen Mall, Shahrah e Suri,, Karachi', '2019-01-05 01:40:02', '2019-01-05 01:40:02', 1),
(12, '2019-01-23', 'Delhi Rabbri House, Pakistan, South M Taufiq Road, Karachi', '2019-01-06 17:34:49', '2019-01-06 17:34:49', 1),
(13, '2019-01-01', 'KFC, Captain Fareed Bukhari Shaheed Road, Jamshed Town, Karachi', '2019-01-06 17:42:41', '2019-01-06 17:42:41', 1),
(14, '2019-01-08', 'Yameen Haleem Merchant, Britto Road, Karachi', '2019-01-05 18:56:25', '2019-01-05 18:56:25', 1),
(15, '2019-01-09', 'Good Broast, Johar Mor Road Service Lane, Karachi', '2019-01-05 19:10:00', '2019-01-05 19:10:00', 6),
(16, '2019-01-08', 'Qureshi Kababish &amp; Nihari Hotel, Service Road, Karachi', '2019-01-05 19:11:16', '2019-01-05 19:11:16', 6),
(17, '2019-01-17', 'Wali Muhammad Hotel, Karachi', '2019-01-05 23:25:02', '2019-01-05 23:25:02', 1),
(18, '2019-01-10', 'Wali Muhammad Hotel, Karachi', '2019-01-05 23:53:51', '2019-01-05 23:53:51', 1),
(19, '2019-01-23', 'Broadway Pizza, Dolmen Mall Haydri, North Service Road, Karachi', '2019-01-06 00:38:56', '2019-01-06 00:38:56', 1),
(20, '2019-01-11', 'Yuan Tung Restaurant, 173-P, Tariq Road, Karachi', '2019-01-06 01:48:30', '2019-01-06 01:48:30', 1),
(21, '2019-01-25', 'Pizza Hut, University Road, Karachi', '2019-01-06 10:06:56', '2019-01-06 10:06:56', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sequelizemeta`
--

CREATE TABLE `sequelizemeta` (
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sequelizemeta`
--

INSERT INTO `sequelizemeta` (`name`) VALUES
('20181226185028-create-users.js'),
('20181226185329-create-meeting-master.js'),
('20181226185412-create-meeting-details.js');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lat` float DEFAULT '24.8602',
  `long` float DEFAULT '67.0699',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `lat`, `long`, `createdAt`, `updatedAt`) VALUES
(1, 'haseeb.93@hotmail.com', '$2a$10$QrTLSPv47Jak9Q4xVZXSw.cGQgbPAIRGyNjt9MRgctVKPxSvSh0xq', 24.859, 67.0101, '2018-12-30 00:00:00', '0000-00-00 00:00:00'),
(2, 'jhanz_619@hotmail.com', '$2a$10$95Gz6Lmzrq4gAWMQ1OewyujJzy.KQ3ylwlSxkUEtldMNKXC8epGIi', 24.8338, 67.0337, '2018-12-30 00:00:00', '0000-00-00 00:00:00'),
(3, 'tayyab_rana@gmail.com', '$2a$10$lECBnngWSFZEaMFeWYIByODtt2mq8yAHlaOXxFTxTTdqQXLnDW6M2', 24.9729, 67.0643, '2018-12-30 00:00:00', '0000-00-00 00:00:00'),
(5, 'fa17mcsw0023@maju.edu.pk', '$2a$10$m463XWHjC8caI.pgsV.4DOkopJJaQi4UwKQ8ymE/R4QmD1APB6/W6', 24.8773, 67.1591, '2018-12-30 00:00:00', '0000-00-00 00:00:00'),
(6, 'basit@gmail.com', '$2a$10$s4c2rth6wKy0BHd.SAr4HuNflY.vU53dbTLG6KY0WP49c2ngI3cH.', 24.9372, 67.0423, '2018-12-30 00:00:00', '0000-00-00 00:00:00'),
(7, 'ahmed@maju.com', '$2a$10$pp44sPaxIumLUzbEIMwrBuFFJY3Ss4.5lGC2s5f897ZwIXmHL7as6', 24.9525, 66.955, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 'abdulRauf@gmail.com', '$2a$10$6OT01DmBvhpvCIz2CFlEMOuWvEb/wwUtatsO3ZNIMmxiyGmcqYRHa', 24.8602, 67.0699, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `meetingdetails`
--
ALTER TABLE `meetingdetails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `meetingmasters`
--
ALTER TABLE `meetingmasters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sequelizemeta`
--
ALTER TABLE `sequelizemeta`
  ADD PRIMARY KEY (`name`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `meetingdetails`
--
ALTER TABLE `meetingdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `meetingmasters`
--
ALTER TABLE `meetingmasters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
